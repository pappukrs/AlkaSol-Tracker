package codeserver.AlkaSol_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlkaSolBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
