package codeserver.AlkaSol_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlkaSolBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlkaSolBackendApplication.class, args);
	}

}
